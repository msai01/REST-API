package com.mythili.restdemo.model;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
public class JustString {

    private String name;
}
