package com.mythili.restdemo.repo;

import com.mythili.restdemo.model.SubmissionDTO;

import java.util.List;

public interface SubmissionRepository {

    SubmissionDTO getSubmission(String id);

    List<SubmissionDTO> getAll();
    SubmissionDTO addSubmission(SubmissionDTO submission);
    SubmissionDTO updateSubmission(SubmissionDTO submission);
    SubmissionDTO deleteSubmission(String id);

}
